//Copyright(c)[2025][AGIROS][TravoDDS] is licensed under Mulan PSL v2.
//
//You can use this software according to the terms and conditions of
//the Mulan PSL v2.You may obtain a copy of Mulan PSL v2 at :
//http://license.coscl.org.cn/MulanPSL2
//
//THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF
//ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
//
//See the Mulan PSL v2 for more details.
#ifndef TRAVODDS_DCPS_SQL_FILTER_H
#define TRAVODDS_DCPS_SQL_FILTER_H

#include <vector>
#include <memory>
#include <string>
#include <mutex>
#include "dcps/base/retcode.h"
#include "dcps/sql/ddssqlfield.h"
#include "dcps/sql/binarytreenode.h"
#include "dcps/sql/ddssqlcondition.h"
#include "dcps/sql/ddssqlpredicate.h"
#include "xtypes/dynamictype.h"


TRAVODDS_NAMESPACE_BEGIN
namespace DDSSQL {

	class DDSSQLFilter
	{
	public:
		DDSSQLFilter(DynamicType* dynType);

		ReturnCode_t InputSQL(const std::string& expression, const std::vector<std::string>& parameters);

		bool Validate(DynamicData* dynData);
	protected:
		std::shared_ptr<DDSSQLCondition> TransformTreeToCondition(const BinaryTreeNode& node, const std::vector<std::string>& parameters);

		std::shared_ptr<DDSSQLCondition> TransformTreeToPredicate(const BinaryTreeNode& node, const std::vector<std::string>& parameters);

		std::shared_ptr<TypicalValue> TransformTreeToValue(const BinaryTreeNode& node, const std::vector<std::string>& parameters);

		// and, or, not
		std::shared_ptr<DDSSQLCondition> TransformTreeToLogical(const BinaryTreeNode& node, const std::vector<std::string>& parameters);
		// between, not betwenn
		std::shared_ptr<DDSSQLCondition> TransformTreeToBetween(const BinaryTreeNode& node, const std::vector<std::string>& parameters);

		bool TransformEnum(std::shared_ptr<TypicalValue> left, const DynamicType* leftdesc, std::shared_ptr<TypicalValue> right, const DynamicType* rightdesc);
	protected:
		bool CheckValueCompatibility(TypicalKind left, TypicalKind right, bool ignoreEnum);

		RelOperationKind GetPredicateOp(const BinaryTreeNode& node);

	private:
		DynamicType* dynType_;

		std::shared_ptr<DDSSQLCondition> root_; // 根节点
		// field 占位
		std::map<std::string, std::shared_ptr<DDSSQLFieldValue>> fields_;

		std::mutex mutex_;

	};
}
TRAVODDS_NAMESPACE_END

#endif
